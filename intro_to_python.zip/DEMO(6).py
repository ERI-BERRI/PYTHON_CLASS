
num = (int) 

input ("Enter any number to test whether it is odd or even:")

if (num % 2) == 0:

              print ("The number is even")

else:

              print ("The provided number is odd")

Output:

print ("Enter any number to test whether it is odd or even:")

887

887 is odd

                
print ("The program above only accepts integers as input. However,") 