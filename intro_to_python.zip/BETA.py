
print( "Welcome to your digital calculator" )
input( "Select an opperation" )



x= input( "Type a number" )
y= input( "Type another number" )

sum= int( x ) + int( y )

print( "The numbers added together are", sum )