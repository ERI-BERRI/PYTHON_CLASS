#Write a program that suggests the user gives you two numbers and find the difference between them


x = input("Type a number")
y = input("Type another number")

difference = int(x) - int(y)
 
print("The diff is", difference)