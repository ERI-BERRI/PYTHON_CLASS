#Write a program that accepts two numbers from the user and calculates their sum.


x = input("Type a number: ")
y = input("Type another number: ")

sum = int(x) + int(y)

print("The sum is: ", sum)