secret_num = 10

user_guess = input("Guess a number")
user_guess = int10 (user_guess)

if user_guess == secret_num:
    print("you have won")
