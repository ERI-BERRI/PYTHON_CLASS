

x = input("Enter a number")
y = input("Enter another number")
z = input("Enter your last number")

average = int(x) + int(y) + int(z) / 2

print("The avrg is", average)