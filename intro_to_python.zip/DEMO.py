
#create a mini-school managment System

#create a program that registers students
#name#email#class#age
student_name= input("Enter your name")
student_email= input("Enter your email")
student__class= input("Enter your class")
student_age= input("Enter your age")

print("Registration complete")
print("Your name is", student_name,"Your class is", student__class)


#Take input of length and breadth of a rectangle user and print area of it.
#Take side of square from user and print area and perimeter of it.
#Write a program o find sqaure of the number

number= input("Enter a Number")
number= int(number)

square= number ** 2
print("The square of a number is", square)
length= input("Enter a length")
length= int(length)

breadth= input("Enter a breadth")
breadth= int(breadth)

area= breadth * length
perimeter= (breadth * 2)+ (length * 2)

print("The perimeter of a Rectangle", breadth)
print("The area of a rectangle is", area)