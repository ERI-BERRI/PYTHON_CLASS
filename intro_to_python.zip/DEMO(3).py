#Write a program that accepts two numbers from the user and calculates their product.

x = input("Type a number")
y = input("Type another number")

product = x * y 
print("The answer will be", product)