
x= input("Enter your number")
y= input("Enter another number")

Average= int(x) + int(y) / 2

print("The avrge is", Average)
